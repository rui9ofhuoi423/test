1. Drag and drop the `resource` folder into your HUD's directory.
2. Go into the `_choose_your_option_` folder and open the folder for your desired option.
3. Drag and drop the `materials` folder from your chosen option into your HUD's directory.
4. Open your HUD's `...\resource\ui\hudplayerclass.res` file with Notepad and add `#base "speedometer.res"` at the very top of the file.


Showcase:

https://github.com/iragaiko

