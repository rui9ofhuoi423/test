"Resource/UI/HudPlayerClass.res"
{
	"speedometer"
	{
		"visible"			"1"
		"enabled"			"1"
		"controlName"		"ImagePanel"
		"fieldName"			"speedometer"
		"zpos"				"-100"
		"xpos"				"cs-0.5"
		"ypos"				"c150"
		"wide"				"42"
		"tall"				"11"
		"image"				"replay/thumbnails/numbers"
		"scaleImage"		"1"
	}
}